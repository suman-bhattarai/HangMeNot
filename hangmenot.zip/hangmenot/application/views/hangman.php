<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/own-style.css') ?>">
	<script src="<?php echo base_url('assets/js/jquery-3.3.1.min.js') ?>"></script>
	
</head>
<body>
<div class="bg">
<div class="container">
<div class="content">
<h1><?php echo $welcome ?></h1>
<h5><i><?php echo $developed ?></i></h5>
<input type="hidden" id="hidvalue" value= <?php echo $word ?>>
<div class="row mrgl-20 mrgr-20">
	<div class="col-md-10 hangman">
	<span class="float-left" style="color:#44342f;">How to Play? </span>
	<span style="color: #75371d">You are presented with a vacant box of word. A hint of letter or a two is given dependending on the length of word. Guess the word within the specified attempt.</span>
   </div>
</div>
<div class="row">
	<div class="col-md-4 hangman">
		<span id="spana">Attempts:&nbsp;</span><span id="spanb">10</span>
	</div>
	<div class=" col-md-4 hangman">
		<span>Enter a Letter Here: </span> &nbsp; <input type = "text" id='val' >
	</div>
	<div class ="col-md-4 hangman">
		<span>Entered Value: &nbsp;  </span><span id='arr_val'></span>
	</div>
</div>
<div class="label-container row justify-content-md-center">
<div class="label">
	<?php for($i=0; $i<$length; $i++) : ?>
		<div  class='input<?php echo $i ?> text'><?php
		if(isset($rand_key[$i])){
			echo $ori_key_val[$i];
		} ?></div>
	 <?php endfor ?>
</div>
</div>
<div class="result">
<p></p>
</div>

</div>
</div>
</div>
<input type="hidden" id="base_url" value="<?php echo base_url() ?>">
<input type="hidden" id="word_id" value="<?php  echo $word_id ?>">
<script type="text/javascript" src="<?php echo base_url('assets/js/script.js') ?>"></script>
</body>
</html>