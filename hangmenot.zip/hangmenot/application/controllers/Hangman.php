<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hangman extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');

		$this->load->model('word_model');

		$digit = $this->word_model->retrieve();

		// echo "<pre>"; print_r($digit);exit;

		//for hint

		
		$data['title'] = "Hangman" ;
		$data['welcome'] = "Welcome to Hangman Game" ;
		$data['developed'] = "Developed by Suman";
		$data['word']=$digit['words'];
		$data['word_id']=$digit['id'];


		$length = strlen($data['word']);
		$data['length'] = $length;

		$hint_number =  round(($length/5)+1);

		$ori_key_val =  str_split($data['word']); //store original index in array
		$new_key_val = $this->shuffle_key_val($ori_key_val);
       $rand_key = array_rand($new_key_val,$hint_number);
       if(!is_array($rand_key)){
       	$rand_key = array($rand_key);
       }
       // print_r($rand_key);
       $data['rand_key'] = array_flip($rand_key);
       $data['ori_key_val'] = $ori_key_val;

       // print_r($rand_key);
       // for($i=0; $i<=$rand_key.count(); $i++){
       // 	$data[$i]= $rand_key[$i]
       // }

		// foreach($letters_original as $key=>$value) {
		// 	$key_values[] = $key;
		// }

		// shuffle($key_values);

		// for ($i=0; $i <$data['hint_number'] ; $i++) { 	
		// }



		// $letters_shuffled = str_shuffle($data['word']);

		// $letters_shuffled = str_split(['']);

		// print_r($key_values);exit;



		// echo $length;exit;
		$this->load->view('hangman',$data);
	}
	function shuffle_key_val($arr)
		{
			$old_keys = array_keys($arr);
			shuffle($old_keys);
			foreach($old_keys as $key) {
				$new[$key] = $arr[$key];
			}
			$arr = $new;
			return $arr;
		}

}
