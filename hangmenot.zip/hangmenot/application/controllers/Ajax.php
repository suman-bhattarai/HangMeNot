<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

	public function method()
	{
		$id = $this->input->post('id');
		$attempts = $this->input->post('attempts');
		$this->load->model('word_model');
		$this->word_model->insert($id,$attempts);

	}
}