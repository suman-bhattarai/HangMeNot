<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Sum extends CI_Controller {

	public function add($a,$b)
	{
		$data['name'] = 'suman';
		$data['a'] = $a;
		$data['b'] = $b;

		$this->load->view('sum',$data);
	}
}
