<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Word_model extends CI_Model {

	public function retrieve()
	{
		$this->db->select();
		$this->db->from('words');

		$rows = $this->db->get();

		// return $rows->result();//object
		// return $rows->result_array(); //array
		return $rows->row_array(); //array
	}
	public function insert($id,$attempts){
		$insert = array(
			'words_id' => $id,
			'attempt'  => $attempts
		);
		// $this->db->insert('records',$insert);
		if($this->db->insert('records',$insert)){
			return true;
		}
		else{
			return false;
		}
	}
}
