<?php function sum(){
	$c = $a + $b;
	return $c;
} ?>