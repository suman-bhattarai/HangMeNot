var word = $('#hidvalue').val() ;
var base_url = $('#base_url').val() ;
var fix_attempt = 10; var i ; var counts = 0; var letters =[];
var len ; var i ; var textarr = []; var recarr = []; var attempt = 10 ;
len = word.length ;
finish = 0;

for (i = 0; i < len; i++) {
	textarr.push(word[i]);
}
// to check and store the repeated letters in the word
function repetition_check(){
	$(textarr).each(function(i,v){
		var counts = 0;
		for(i=0 ; i<len; i++){
			if(word.charAt(i) == v ){
				counts++ ;
			}
		}
		if(counts>1){
			letters.push(v) ;
		}

	})
}
// Function checking match between letters[] and recarr[] and removing the letter from array
function match(){

	console.log(letters);//array of repeated characters
	console.log("Here");
	console.log(recarr); // array of entered characters including hint

	$(recarr).each(function(i,v){

		for(i = 0; i < letters.length; i++){
			if(v == letters[i]){
				itemRemove = v ;
				recarr.splice($.inArray(itemRemove,recarr),1);
			}
		}
	})
	console.log("After each");
	console.log(letters);//array of repeated characters
	console.log("Here");
	console.log(recarr); 
}

function charcheck(display){
	var fla = 0;
	$(textarr).each(function(i,v){
		if(v == display){
			setval(i,v);
			fla = 1;
		}
	})
	if(fla == 0){
		--attempt;
	}
	if(attempt == 0){
		$("div.result p").html("<b>YOU LOOSE</b>");
		$( "#val" ).prop( "disabled", true );
		finish = 1;
		return false;
	}
	console.log(attempt);
}
function records(display){
	var flag = 0;
	// if(attempt == 0){
	// 	$("div.result p").html("<b>YOU LOOSE</b>");
	// 	finish = 1;
	// 	return false;
	// }
	if(recarr.length == 0){
		recarr.push(display);
		charcheck(display);
		$('#arr_val').html(recarr);
	}
	else{
		$(recarr).each(function(i,v){
			if(v == display){
				alert('You Have Already Entered This Letter!! Try Entering New Letter');
				flag = 1;
				return false;
			}
		})
		if(flag == 0 ){
			recarr.push(display);
			charcheck(display);
			$('#arr_val').html(recarr.join(" "));
		}
	}
	// console.log(recarr);	
}

function count(){
	var flaga = 0;
	$('div.text').each(function(){
		var letter = $(this).html();
		if(letter != ""){
			flaga++ ;
		}
	})
	if(flaga==len){
		$("div.result p").html("<b>CONGRATULATIONS!!! YOU WON</b>");
		$( "#val" ).prop( "disabled", true );
		finish = 1;


		$.ajax({
		  url : base_url + 'ajax/method',
		  type : 'POST',
		  data : {id: $('#word_id').val(), attempts : fix_attempt-attempt}
		})
		.done(function(response) {
			alert(response);
		})
		.fail(function(response) {
			alert("Failure");
		})
		.always(function() {
			alert("Always");
		})
		return false;
	}
}

function setval(i,v){
	$('.input'+i).html(v);
	count();
}

$(document).ready(function(){
	$('.text').each(function(){
		if($(this).html()!=""){
			recarr.push($(this).html()); // Pushing the hints to our records(i.e recarr)
		} 
	})
	repetition_check(); 
	match();

	console.log(recarr);

	$('#val').keyup(function(){
		var display = $('#val').val();
		if(finish == 1) {
			alert("No need to enter");
			return;
		}
		records(display);
		// charcheck(display);
		$('#val').val("");
		$('#spanb').html(attempt);
	})

})


