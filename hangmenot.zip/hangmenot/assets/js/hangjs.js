//THE HANGMAN GAME-For No repetition of letters in word

var word = "suman" ;
var attempts = 10;
var length = word.length;
var i;
var a; 
arr = [];
function charcheck(display){
	var match = 0;
	for(i=0 ; i<length ; i++){
		// alert(i);
		if(word.charAt(i)==display){
			insert(display,i);
			match = 1;
			break;
			// return word.charAt(i);
		}
		else{
			match = 0;
		}
		
	}
	// attempts = attempts - 1 ;
	return match ;
}
function records(display){	
		// arr.push(display);
	// alert(display);
	var flag = 0;
	$(arr).each(function(i,v){
		if(display==v){
			alert('You Have Already Entered this letter');
			flag = 1;
		}
	})
	if(flag == 0){
		alert('afyter');
		arr.push(display);
		console.log(arr);
	}

}
function insert(display,i){
	$('.input'+i).val(display);
}

$(document).ready(function(){
    $("#val").keyup(function(){
    	var display = $(this).val();
    	charcheck(display);
    	records(display);
    	$("#val").val("");
 
    });
});

// $(document).ready(function(){
//     $("#val").keyup(function(){
//     	// alert("Text: " + $(this).val());
//     	var display = $(this).val();
//     	alert(display);

       
//     });
// });
// $(document).ready(function(){
//     $("button").click(function(){
//     	// alert("Text: " + $(this).val());
//     	// var display = $(this).val();
//          alert('hello');
       
//     });
// });